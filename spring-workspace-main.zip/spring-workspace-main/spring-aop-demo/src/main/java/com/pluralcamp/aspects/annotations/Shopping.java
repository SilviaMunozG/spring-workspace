package com.pluralcamp.aspects.annotations;

public interface Shopping {
	void buy(boolean error) throws Exception;
}

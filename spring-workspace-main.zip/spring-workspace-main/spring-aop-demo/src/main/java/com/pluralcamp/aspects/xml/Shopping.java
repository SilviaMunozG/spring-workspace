package com.pluralcamp.aspects.xml;

public abstract class Shopping {
	public abstract void buy(boolean error) throws Exception;
}

package com.pluralcamp.reflection;

public class HelloWorld {
	
	public void sayHello() {
		System.out.printf("Hello World %n");
	}
	
	public void sayHello(String name) {
		System.out.printf("Hello %s%n", name);
	}
}
